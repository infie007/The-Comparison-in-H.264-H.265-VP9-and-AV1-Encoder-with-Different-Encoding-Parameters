import os
import sys

os.chdir("./source_code")

def main(argv):

	if len(argv)!=2:
		print("Wrong number of arguments! Please use -h to obtain helps.")

	else:
		if argv[1] == "-h":
			print("There are five support modes: -ui, -encode_b, -encode_c, -decode and -study_other_paras.")
			print("-ui                 Open the AugusEncoder UI system. (See what functions it has in README.)")
			print("-encode_b           Encode with bitrate mode. (See how it works in README.)")
			print("-encode_c           Encode with crf mode. (See how it works in README.)")
			print("-decode             Decode bitrate mode and crf mode with metrics computing. (See how it works in README.)")
			print("-study_other_paras  Study other parameters include a/c/v br, presets and 2-pass. (See how it works in README.)")
			print("-pwd                Check the current dir.")
		
		elif argv[1] == "-ui":
			os.system("python AugusEncoder.py")

		elif argv[1] == "-encode_b":
			os.system("python encode_with_bitrate.py")

		elif argv[1] == "-encode_c":
			os.system("python encode_with_crf.py")

		elif argv[1] == "-decode":
			os.system("python decode_with_metrics_compute.py")

		elif argv[1] == "-study_other_paras":
			os.system("python encode_with_acvbr_preset_2pass.py")

		elif argv[1] == "-pwd":
			os.system("pwd")
			#os.system("python ./chdir/chdir.py")

		else:
			print("Wrong arguments!")
 
if __name__ == "__main__":
	main(sys.argv)

