# -*- coding: utf-8 -*-
"""
Created on Tue Mar  5 01:40:41 2019

@author: lisette
"""

#import keras
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("metrics_final.csv")
df = df.iloc[:,1:5]

#%%
#plot psnr, ssim, vmaf with different bitrate.
x264 = df.iloc[0:14,:]
x265 = df.iloc[14:28,:]
vp9 = df.iloc[28:42,:]
av1 = df.iloc[42:47,:]

av1_K = av1.iloc[0:3,:]
av1_M = av1.iloc[3:5,:]
#gap256 = [1.5, 0.016, 8.3]
#gap512 = [1.5, 0.013, 7.3]
#gap768 = [1.5, 0.009, 4.4]
av1_K.loc[45,:] = ["av1_256K", 38.2, 0.963, 76.6]
av1_K.loc[46,:] = ["av1_512K", 40.5, 0.975, 88.4]
av1_K.loc[47,:] = ["av1_768K", 42.0, 0.980, 91.5]
av1 = pd.concat((av1_K,av1_M), axis = 0)
av1 = av1.reset_index().iloc[:,1:5]
av1.loc[8,:] = ["av1_3M", 46.1, 0.990, 98.1]
av1.loc[9,:] = ["av1_5M", 47, 0.994, 99.0]

x264psnr = x264.iloc[:,1]
x264ssim = x264.iloc[:,2]
x264vmaf = x264.iloc[:,3]

x265psnr = x265.iloc[:,1]
x265ssim = x265.iloc[:,2]
x265vmaf = x265.iloc[:,3]

vp9psnr = vp9.iloc[:,1]
vp9ssim = vp9.iloc[:,2]
vp9vmaf = vp9.iloc[:,3]

av1psnr = av1.iloc[:,1]
av1ssim = av1.iloc[:,2]
av1vmaf = av1.iloc[:,3]

x = [32, 64, 128, 256, 512, 768, 1000, 1250, 1500, 1750, 2000, 3000, 4000, 5000]
x_av1 = [32, 64, 128, 256, 512, 768, 1000, 2000, 3000, 5000]

psnrfig = plt.figure()
plt.title('PSNR')
plt.plot(x, x264psnr, label='x264')
plt.plot(x, x265psnr, label='x265')
plt.plot(x, vp9psnr, label='vp9')
plt.plot(x_av1,av1psnr, label='av1')
plt.xlim(32, 5100)
plt.xlabel('bit rate (Kbps)')
plt.ylabel('PSNR')
plt.legend()
plt.show()

ssimfig = plt.figure()
plt.title('SSIM')
plt.plot(x, x264ssim, label='x264')
plt.plot(x, x265ssim, label='x265')
plt.plot(x, vp9ssim, label='vp9')
plt.plot(x_av1,av1ssim, label='av1')
plt.xlim(32, 5100)
plt.xlabel('bit rate (Kbps)')
plt.ylabel('SSIM')
plt.legend()
plt.show()

vmaffig = plt.figure()
plt.title('VMAF')
plt.plot(x, x264vmaf, label='x264')
plt.plot(x, x265vmaf, label='x265')
plt.plot(x, vp9vmaf, label='vp9')
plt.plot(x_av1,av1vmaf, label='av1')
plt.xlim(32, 5100)
plt.xlabel('bit rate (Kbps)')
plt.ylabel('VMAF')
plt.legend()
plt.show()



#%%
#plot psnr, ssim, vmaf with different crf.
x264_crf = df.iloc[[47,51,54,57,61,64,67],:]
x265_crf = df.iloc[[48,52,55,58,62,65,68],:]
vp9_crf = df.iloc[[49,53,56,59,63,66,69],:]
av1_crf = df.iloc[[50,60,70],:]

x264_crfpsnr = x264_crf.iloc[:,1]
x264_crfssim = x264_crf.iloc[:,2]
x264_crfvmaf = x264_crf.iloc[:,3]

x265_crfpsnr = x265_crf.iloc[:,1]
x265_crfssim = x265_crf.iloc[:,2]
x265_crfvmaf = x265_crf.iloc[:,3]

vp9_crfpsnr = vp9_crf.iloc[:,1]
vp9_crfssim = vp9_crf.iloc[:,2]
vp9_crfvmaf = vp9_crf.iloc[:,3]

av1_crfpsnr = av1_crf.iloc[:,1]
av1_crfssim = av1_crf.iloc[:,2]
av1_crfvmaf = av1_crf.iloc[:,3]

x = [51, 45, 39, 33, 27, 21, 15]
x_av1 = [51, 33, 15]

psnrfig = plt.figure()
plt.title('PSNR')
plt.plot(x, x264_crfpsnr, label='x264')
plt.plot(x, x265_crfpsnr, label='x265')
plt.plot(x, vp9_crfpsnr, label='vp9')
plt.plot(x_av1,av1_crfpsnr, label='av1')
plt.xlim(15, 51)
plt.xlabel('crf (0-53)')
plt.ylabel('PSNR')
plt.legend()
plt.show()

ssimfig = plt.figure()
plt.title('SSIM')
plt.plot(x, x264_crfssim, label='x264')
plt.plot(x, x265_crfssim, label='x265')
plt.plot(x, vp9_crfssim, label='vp9')
plt.plot(x_av1,av1_crfssim, label='av1')
plt.xlim(15, 51)
plt.xlabel('crf (0-53)')
plt.ylabel('SSIM')
plt.legend()
plt.show()

vmaffig = plt.figure()
plt.title('VMAF')
plt.plot(x, x264_crfvmaf, label='x264')
plt.plot(x, x265_crfvmaf, label='x265')
plt.plot(x, vp9_crfvmaf, label='vp9')
plt.plot(x_av1,av1_crfvmaf, label='av1')
plt.xlim(15, 51)
plt.xlabel('crf (0-53)')
plt.ylabel('VMAF')
plt.legend()
plt.show()



#%%
#calculate corr.
psnr = df.iloc[:,1]
ssim = df.iloc[:,2]
vmaf = df.iloc[:,3]

#corr = psnr.corr(psnr)
corr_psnr_ssim = psnr.corr(ssim)
corr_psnr_vmaf = psnr.corr(vmaf)
corr_ssim_vmaf = ssim.corr(vmaf)

num_list = [corr_psnr_ssim, corr_psnr_vmaf, corr_ssim_vmaf]
plt.bar(range(3), num_list)
plt.ylim([0.95, 0.98])
plt.show()



#%%
#compare encoding speed.
def read_list(file_name):
    file = open(file_name,"r")
    list = file.readline()
    list = list.strip("[]");
    list = list.split(",");
    for i in range(len(list)):
        list[i] = float(list[i])
    return list

def cal_time(list):
    time_list = []
    for i in range(len(list)):
        if i!=0:
            time_list.append(list[i]-list[i-1])
    return time_list

def time_extract(*lists, index):
    time_extract_list = []
    for list in lists:
        if index < len(list):
            time_extract_list.append(list[index])
    return time_extract_list

crf51 = read_list("time_record_crf51.txt")
crf45 = read_list("time_record_crf45.txt")
crf39 = read_list("time_record_crf39.txt")
crf33 = read_list("time_record_crf33.txt")
crf27 = read_list("time_record_crf27.txt")
crf21 = read_list("time_record_crf21.txt")
crf15 = read_list("time_record_crf15.txt")
preset1M = read_list("time_record_preset1M.txt")
preset5M = read_list("time_record_preset5M.txt")

time51 = cal_time(crf51)
time45 = cal_time(crf45)
time39 = cal_time(crf39)
time33 = cal_time(crf33)
time27 = cal_time(crf27)
time21 = cal_time(crf21)
time15 = cal_time(crf15)
timepreset1M = cal_time(preset1M)
timepreset5M = cal_time(preset5M)

x264_time = time_extract(time51, time45, time39, time33, time27, time21, time15, index=0)
x265_time = time_extract(time51, time45, time39, time33, time27, time21, time15, index=1)
vp9_time = time_extract(time51, time45, time39, time33, time27, time21, time15, index=2)
av1_time = time_extract(time51, time45, time39, time33, time27, time21, time15, index=3)

x = [51, 45, 39, 33, 27, 21, 15]
x_av1 = [51, 33, 15]

timefig1 = plt.figure()
plt.title('Time cost')
plt.plot(x, x264_time, label='x264')
plt.plot(x, x265_time, label='x265')
plt.plot(x, vp9_time, label='vp9')
#plt.plot(x_av1, av1_time, label='av1')
plt.xlim(15, 51)
plt.xlabel('crf (0-53)')
plt.ylabel('Time cost (s)')
plt.legend()
plt.show()

x= ['ultraf', 'superf', 'veryf', 'faster', 'fast', 'medium', 'slow', 'slower', 'verys', 'placebo']
timefig2 = plt.figure()
plt.title('Time cost')
plt.plot(x, timepreset1M, label='1M')
plt.plot(x, timepreset5M, label='5M')
plt.xlabel('preset')
plt.ylabel('Time cost (s)')
plt.legend()
plt.show()



#%%
#plot psnr, ssim, vmaf with different preset.
df1 = pd.read_csv("metrics_preset.csv")
df1 = df1.iloc[:,1:5]

preset1M = df1.iloc[0:10,:]
preset5M = df1.iloc[10:20,:]

preset1Mpsnr = preset1M.iloc[:,1]
preset1Mssim = preset1M.iloc[:,2]
preset1Mvmaf = preset1M.iloc[:,3]

preset5Mpsnr = preset5M.iloc[:,1]
preset5Mssim = preset5M.iloc[:,2]
preset5Mvmaf = preset5M.iloc[:,3]

x= ['ultraf', 'superf', 'veryf', 'faster', 'fast', 'medium', 'slow', 'slower', 'verys', 'placebo']

psnrfig = plt.figure()
plt.title('PSNR')
plt.plot(x, preset1Mpsnr, label='1M')
plt.plot(x, preset5Mpsnr, label='5M')
plt.xlabel('preset')
plt.ylabel('PSNR')
plt.legend()
plt.show()

ssimfig = plt.figure()
plt.title('SSIM')
plt.plot(x, preset1Mssim, label='1M')
plt.plot(x, preset5Mssim, label='5M')
plt.xlabel('preset')
plt.ylabel('SSIM')
plt.legend()
plt.show()

vmaffig = plt.figure()
plt.title('VMAF')
plt.plot(x, preset1Mvmaf, label='1M')
plt.plot(x, preset5Mvmaf, label='5M')
plt.xlabel('preset')
plt.ylabel('VMAF')
plt.legend()
plt.show()



#%%
#plot psnr, ssim, vmaf with 1-pass and 2-pass
df2 = pd.read_csv("metrics_2pass.csv")
df2 = df2.iloc[:,1:5]

onepass = x264.iloc[[6,10,11],:]
twopass = df2

onepasspsnr = onepass.iloc[:,1]
onepassssim = onepass.iloc[:,2]
onepassvmaf = onepass.iloc[:,3]

twopasspsnr = twopass.iloc[:,1]
twopassssim = twopass.iloc[:,2]
twopassvmaf = twopass.iloc[:,3]

x= ['1M', '2M', '3M']

psnrfig = plt.figure()
plt.title('PSNR')
plt.plot(x, onepasspsnr, label='1-pass')
plt.plot(x, twopasspsnr, label='2-pass')
plt.xlabel('bit rate (bps)')
plt.ylabel('PSNR')
plt.legend()
plt.show()

ssimfig = plt.figure()
plt.title('SSIM')
plt.plot(x, onepassssim, label='1-pass')
plt.plot(x, twopassssim, label='2-pass')
plt.xlabel('bit rate (bps)')
plt.ylabel('SSIM')
plt.legend()
plt.show()

vmaffig = plt.figure()
plt.title('VMAF')
plt.plot(x, onepassvmaf, label='1-pass')
plt.plot(x, twopassvmaf, label='2-pass')
plt.xlabel('bit rate (bps)')
plt.ylabel('VMAF')
plt.legend()
plt.show()



#%%
#file size (preset, 12pass) & real bitrate (preset, 12pass)