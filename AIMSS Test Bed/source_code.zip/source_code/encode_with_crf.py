import os
import time

os.chdir("..")
os.chdir("./ffmpeg_static_with_VMAF/ffmpeg_static")
os.system("pwd")

#51
time51x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 51 -b:v 0 ./encoded_crf/encoded_x264_crf51.mp4")
time51x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 51 -b:v 0 ./encoded_crf/encoded_x265_crf51.mp4")
time51vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 51 -b:v 0 ./encoded_crf/encoded_vp9_crf51.mkv")
time51av1 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 51 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf51.mkv")
time51end = time.time()

time_record = [time51x264,time51x265,time51vp9,time51av1,time51end]
print time_record

file=open('time_record_crf51.txt','w') 
file.write(str(time_record)); 
file.close() 

#45
time45x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 45 -b:v 0 ./encoded_crf/encoded_x264_crf45.mp4")
time45x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 45 -b:v 0 ./encoded_crf/encoded_x265_crf45.mp4")
time45vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 45 -b:v 0 ./encoded_crf/encoded_vp9_crf45.mkv")
#time45av1 = time.time()
#os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 45 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf45.mkv")
time45end = time.time()

time_record = [time45x264,time45x265,time45vp9,time45end]
print time_record

file=open('time_record_crf45.txt','w') 
file.write(str(time_record)); 
file.close() 

#39
time39x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 39 -b:v 0 ./encoded_crf/encoded_x264_crf39.mp4")
time39x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 39 -b:v 0 ./encoded_crf/encoded_x265_crf39.mp4")
time39vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 39 -b:v 0 ./encoded_crf/encoded_vp9_crf39.mkv")
#time39av1 = time.time()
#os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 39 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf39.mkv")
time39end = time.time()

time_record = [time39x264,time39x265,time39vp9,time39end]
print time_record

file=open('time_record_crf39.txt','w') 
file.write(str(time_record)); 
file.close() 

#33
time33x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 33 -b:v 0 ./encoded_crf/encoded_x264_crf33.mp4")
time33x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 33 -b:v 0 ./encoded_crf/encoded_x265_crf33.mp4")
time33vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 33 -b:v 0 ./encoded_crf/encoded_vp9_crf33.mkv")
time33av1 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 33 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf33.mkv")
time33end = time.time()

time_record = [time33x264,time33x265,time33vp9,time33av1,time33end]
print time_record

file=open('time_record_crf33.txt','w') 
file.write(str(time_record)); 
file.close() 

#27
time27x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 27 -b:v 0 ./encoded_crf/encoded_x264_crf27.mp4")
time27x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 27 -b:v 0 ./encoded_crf/encoded_x265_crf27.mp4")
time27vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 27 -b:v 0 ./encoded_crf/encoded_vp9_crf27.mkv")
#time27av1 = time.time()
#os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 27 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf27.mkv")
time27end = time.time()

time_record = [time27x264,time27x265,time27vp9,time27end]
print time_record

file=open('time_record_crf27.txt','w') 
file.write(str(time_record)); 
file.close() 

#21
time21x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 21 -b:v 0 ./encoded_crf/encoded_x264_crf21.mp4")
time21x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 21 -b:v 0 ./encoded_crf/encoded_x265_crf21.mp4")
time21vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 21 -b:v 0 ./encoded_crf/encoded_vp9_crf21.mkv")
#time21av1 = time.time()
#os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 21 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf21.mkv")
time21end = time.time()

time_record = [time21x264,time21x265,time21vp9,time21end]
print time_record

file=open('time_record_crf21.txt','w') 
file.write(str(time_record)); 
file.close() 

#15
time15x264 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -crf 15 -b:v 0 ./encoded_crf/encoded_x264_crf15.mp4")
time15x265 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -crf 15 -b:v 0 ./encoded_crf/encoded_x265_crf15.mp4")
time15vp9 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -crf 15 -b:v 0 ./encoded_crf/encoded_vp9_crf15.mkv")
time15av1 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -crf 15 -b:v 0 -strict experimental ./encoded_crf/encoded_av1_crf15.mkv")
time15end = time.time()

time_record = [time15x264,time15x265,time15vp9,time15av1,time15end]
print time_record

file=open('time_record_crf15.txt','w') 
file.write(str(time_record)); 
file.close() 





