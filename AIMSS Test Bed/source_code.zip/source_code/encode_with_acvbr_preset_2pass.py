import os
import re
import commands
import pandas as pd
import time

os.chdir("..")
os.chdir("./ffmpeg_static_with_VMAF/ffmpeg_static")
os.system("pwd")

#study of abr cbr vbr. (encode+decode)
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -x264-params \"nal-hrd=cbr\" -minrate 32K -b:v 32K -maxrate 32K ./encoded_cbr/encoded_x264cbr_32K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -minrate 16K -b:v 32K -maxrate 48K ./encoded_cbr/encoded_x264vbr_32K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 32K ./encoded_cbr/encoded_x264abr_32K.mp4")

os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -x264-params \"nal-hrd=cbr\" -minrate 1M -b:v 1M -maxrate 1M ./encoded_cbr/encoded_x264cbr_1M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -minrate 0.5M -b:v 1M -maxrate 1.5M ./encoded_cbr/encoded_x264vbr_1M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M ./encoded_cbr/encoded_x264abr_1M.mp4")

#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264cbr_32K.mp4")
#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264Vbr_32K.mp4")
#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264abr_32K.mp4")

#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264cbr_1M.mp4")
#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264vbr_1M.mp4")
#os.system("ffprobe -show_format -i ./encoded_cbr/encoded_x264abr_1M.mp4")

list1 = ["x264cbr_1M", "x264vbr_1M", "x264abr_1M"]

df = pd.DataFrame(columns=['CODEC', 'PSNR', 'SSIM', 'VMAF'])

for i in range(len(list1)):
	
	label = list1[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded_cbr/encoded_%s.mp4 ./decoded_cbr/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded_cbr/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded_cbr/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded_cbr/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i,:] = metrics

	os.system("rm -f ./decoded_cbr/decoded_%s.y4m" %label)

df.to_csv("metrics_cbr.csv")

#study of presets. (encode+decode)
time1Mx264uf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset ultrafast ./encoded_preset/encoded_x264ultrafast_1M.mp4")
time1Mx264sf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset superfast ./encoded_preset/encoded_x264superfast_1M.mp4")
time1Mx264vf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset veryfast ./encoded_preset/encoded_x264veryfast_1M.mp4")
time1Mx264fe = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset faster ./encoded_preset/encoded_x264faster_1M.mp4")
time1Mx264ft = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset fast ./encoded_preset/encoded_x264fast_1M.mp4")
time1Mx264mm = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset medium ./encoded_preset/encoded_x264medium_1M.mp4")
time1Mx264sw = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset slow ./encoded_preset/encoded_x264slow_1M.mp4")
time1Mx264sr = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset slower ./encoded_preset/encoded_x264slower_1M.mp4")
time1Mx264vs = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset veryslow ./encoded_preset/encoded_x264veryslow_1M.mp4")
time1Mx264po = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -preset placebo ./encoded_preset/encoded_x264placebo_1M.mp4")
time1Mx264end = time.time()

time_record = [time1Mx264uf,time1Mx264sf,time1Mx264vf,time1Mx264fe,time1Mx264ft,time1Mx264mm,time1Mx264sw,time1Mx264sr,time1Mx264vs,time1Mx264po,time1Mx264end]
print time_record

file=open('time_record_preset1M.txt','w') 
file.write(str(time_record)); 
file.close() 

time5Mx264uf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset ultrafast ./encoded_preset/encoded_x264ultrafast_5M.mp4")
time5Mx264sf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset superfast ./encoded_preset/encoded_x264superfast_5M.mp4")
time5Mx264vf = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset veryfast ./encoded_preset/encoded_x264veryfast_5M.mp4")
time5Mx264fe = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset faster ./encoded_preset/encoded_x264faster_5M.mp4")
time5Mx264ft = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset fast ./encoded_preset/encoded_x264fast_5M.mp4")
time5Mx264mm = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset medium ./encoded_preset/encoded_x264medium_5M.mp4")
time5Mx264sw = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset slow ./encoded_preset/encoded_x264slow_5M.mp4")
time5Mx264sr = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset slower ./encoded_preset/encoded_x264slower_5M.mp4")
time5Mx264vs = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset veryslow ./encoded_preset/encoded_x264veryslow_5M.mp4")
time5Mx264po = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M -preset placebo ./encoded_preset/encoded_x264placebo_5M.mp4")
time5Mx264end = time.time()

time_record = [time5Mx264uf,time5Mx264sf,time5Mx264vf,time5Mx264fe,time5Mx264ft,time5Mx264mm,time5Mx264sw,time5Mx264sr,time5Mx264vs,time5Mx264po,time5Mx264end]
print time_record

file=open('time_record_preset5M.txt','w') 
file.write(str(time_record)); 
file.close() 

list1 = ["x264ultrafast_1M", "x264superfast_1M", "x264veryfast_1M", "x264faster_1M", "x264fast_1M", "x264medium_1M", "x264slow_1M", "x264slower_1M", "x264veryslow_1M", "x264placebo_1M", "x264ultrafast_5M", "x264superfast_5M", "x264veryfast_5M", "x264faster_5M", "x264fast_5M", "x264medium_5M", "x264slow_5M", "x264slower_5M", "x264veryslow_5M", "x264placebo_5M"]

df = pd.DataFrame(columns=['CODEC', 'PSNR', 'SSIM', 'VMAF'])

for i in range(len(list1)):
	
	label = list1[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded_preset/encoded_%s.mp4 ./decoded_preset/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded_preset/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded_preset/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded_preset/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i,:] = metrics

	os.system("rm -f ./decoded_preset/decoded_%s.y4m" %label)

df.to_csv("metrics_preset.csv")

#study of 2pass
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -pass 1 -an -f mp4 /dev/null && ./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M -pass 2 ./encoded_2pass/encoded_x2642pass_1M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 2M -pass 1 -an -f mp4 /dev/null && ./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 2M -pass 2 ./encoded_2pass/encoded_x2642pass_2M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 3M -pass 1 -an -f mp4 /dev/null && ./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 3M -pass 2 ./encoded_2pass/encoded_x2642pass_3M.mp4")

list1 = ["x2642pass_1M", "x2642pass_2M", "x2642pass_3M"]

df = pd.DataFrame(columns=['CODEC', 'PSNR', 'SSIM', 'VMAF'])

for i in range(len(list1)):
	
	label = list1[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded_2pass/encoded_%s.mp4 ./decoded_2pass/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded_2pass/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded_2pass/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded_2pass/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i,:] = metrics

	os.system("rm -f ./decoded_2pass/decoded_%s.y4m" %label)

df.to_csv("metrics_2pass.csv")


