# -*- coding: utf-8 -*- 

###########################################################################
## Python code generated with wxFormBuilder (version Jun 17 2015)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import os

import re
import commands
import pandas as pd

###########################################################################
## Class MyFrame1
###########################################################################

class MyFrame1 ( wx.Frame ):
	
	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = "Augus Encoder", pos = wx.DefaultPosition, size = wx.Size( 500, 240 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )
		
		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )

		self.m_notebook1 = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer0 = wx.BoxSizer( wx.VERTICAL )
		bSizer0.Add( self.m_notebook1, 1, wx.EXPAND |wx.ALL, 5 )

		self.m_panel1 = wx.Panel(self.m_notebook1, -1)

		#add panel1 here.
		bSizer1 = wx.BoxSizer( wx.VERTICAL )

		bSizer2 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_textCtrl1 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer2.Add( self.m_textCtrl1, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button1 = wx.Button( self.m_panel1, wx.ID_ANY, u"Translate", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button1.Bind(wx.EVT_BUTTON, self.translate_bit)
		bSizer2.Add( self.m_button1, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button2 = wx.Button( self.m_panel1, wx.ID_ANY, u"Encode", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button2.Bind(wx.EVT_BUTTON, self.encode_bit)
		bSizer2.Add( self.m_button2, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer1.Add( bSizer2, 1, wx.EXPAND, 5 )
		
		bSizer3 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText1 = wx.StaticText( self.m_panel1, wx.ID_ANY, u" Encoder (x264, x265, vp9, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )
		bSizer3.Add( self.m_staticText1, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl2 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer3.Add( self.m_textCtrl2, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer1.Add( bSizer3, 1, wx.EXPAND, 5 )
		
		bSizer4 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText2 = wx.StaticText( self.m_panel1, wx.ID_ANY, u" Bitrate (Kbps) (32, 64, 128, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2.Wrap( -1 )
		bSizer4.Add( self.m_staticText2, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl3 = wx.TextCtrl( self.m_panel1, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer4.Add( self.m_textCtrl3, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer1.Add( bSizer4, 1, wx.EXPAND, 5 )

		self.m_panel1.SetSizer( bSizer1 )
		self.m_panel1.Layout()
		bSizer1.Fit( self.m_panel1 )

		self.m_notebook1.AddPage( self.m_panel1, u"bitrate Encoder", False )

		self.m_panel2 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		# add panel 2 here.

		bSizer5 = wx.BoxSizer( wx.VERTICAL )

		bSizer6 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_textCtrl4 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer6.Add( self.m_textCtrl4, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button3 = wx.Button( self.m_panel2, wx.ID_ANY, u"Translate", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button3.Bind(wx.EVT_BUTTON, self.translate_crf)
		bSizer6.Add( self.m_button3, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button4 = wx.Button( self.m_panel2, wx.ID_ANY, u"Encode", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button4.Bind(wx.EVT_BUTTON, self.encode_crf)
		bSizer6.Add( self.m_button4, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer5.Add( bSizer6, 1, wx.EXPAND, 5 )
		
		bSizer7 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText3 = wx.StaticText( self.m_panel2, wx.ID_ANY, u" Encoder (x264, x265, vp9, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )
		bSizer7.Add( self.m_staticText3, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl5 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer7.Add( self.m_textCtrl5, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer5.Add( bSizer7, 1, wx.EXPAND, 5 )
		
		bSizer8 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText4 = wx.StaticText( self.m_panel2, wx.ID_ANY, u" CRF (0-51) (51, 45, 39, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )
		bSizer8.Add( self.m_staticText4, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl6 = wx.TextCtrl( self.m_panel2, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer8.Add( self.m_textCtrl6, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer5.Add( bSizer8, 1, wx.EXPAND, 5 )

		self.m_panel2.SetSizer( bSizer5 )
		self.m_panel2.Layout()
		bSizer5.Fit( self.m_panel2 )
		self.m_notebook1.AddPage( self.m_panel2, u"crf Encoder", False )

		self.m_panel3 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		# add panel 3 here.

		bSizer9 = wx.BoxSizer( wx.VERTICAL )

		bSizer10 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_textCtrl7 = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer10.Add( self.m_textCtrl7, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button5 = wx.Button( self.m_panel3, wx.ID_ANY, u"Translate", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button5.Bind(wx.EVT_BUTTON, self.translate_decode)
		bSizer10.Add( self.m_button5, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_button6 = wx.Button( self.m_panel3, wx.ID_ANY, u"Decode", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button6.Bind(wx.EVT_BUTTON, self.decode)
		bSizer10.Add( self.m_button6, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer9.Add( bSizer10, 1, wx.EXPAND, 5 )
		
		bSizer11 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText5 = wx.StaticText( self.m_panel3, wx.ID_ANY, u" Encoder (x264, x265, vp9, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText5.Wrap( -1 )
		bSizer11.Add( self.m_staticText5, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl8 = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer11.Add( self.m_textCtrl8, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer9.Add( bSizer11, 1, wx.EXPAND, 5 )
		
		bSizer12 = wx.BoxSizer( wx.HORIZONTAL )
		
		self.m_staticText6 = wx.StaticText( self.m_panel3, wx.ID_ANY, u" Bitrate/CRF? (32K, 64K, 1M OR 51, 45, etc.)", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText6.Wrap( -1 )
		bSizer12.Add( self.m_staticText6, 0, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		self.m_textCtrl9 = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer12.Add( self.m_textCtrl9, 1, wx.ALL|wx.ALIGN_CENTER_VERTICAL, 5 )
		
		
		bSizer9.Add( bSizer12, 1, wx.EXPAND, 5 )

		self.m_panel3.SetSizer( bSizer9 )
		self.m_panel3.Layout()
		bSizer9.Fit( self.m_panel3 )

		self.m_notebook1.AddPage( self.m_panel3, u"Decoder", False )

		self.SetSizer( bSizer0 )
		self.Layout()
		
		self.Centre( wx.BOTH )

	def translate_bit(self, event):

		flag = 0
		encoder = self.m_textCtrl2.GetValue()
		if encoder == 'x264':
			lib = 'libx264'
		elif encoder == 'x265':
			lib = 'libx265'
		elif encoder == 'vp9':
			lib = 'libvpx-vp9'
		else:
			dlg = wx.MessageDialog(None, u"Error encoder type!", u"Error encoder type", wx.YES_NO | wx.ICON_QUESTION)
        		dlg.ShowModal()
			flag = 1
		
		bitrate = self.m_textCtrl3.GetValue()

		if flag == 0: 
			str = './ffmpeg -i ./y4m/source.y4m -c:v %s -b:v %sK ./encoded_ui/encoded_%s_%sK.mkv' %(lib, bitrate, encoder, bitrate)
			self.m_textCtrl1.SetValue(str)

	def encode_bit(self, event):
		self.m_button2.Enable(False)
		str = self.m_textCtrl1.GetValue()
		if os.system(str) == 0:
			dlg = wx.MessageDialog(None, u"Encode complete!", u"Encode complete", wx.YES_NO | wx.ICON_QUESTION)
			dlg.ShowModal()
		#else:
			#dlg = wx.MessageDialog(None, u"Wrong bitrate!", u"ncode Wrong bitrate", wx.YES_NO | wx.ICON_QUESTION)
		self.m_button2.Enable(True)

	def translate_crf(self, event):

		flag = 0
		encoder = self.m_textCtrl5.GetValue()
		if encoder == 'x264':
			lib = 'libx264'
		elif encoder == 'x265':
			lib = 'libx265'
		elif encoder == 'vp9':
			lib = 'libvpx-vp9'
		else:
			dlg = wx.MessageDialog(None, u"Error encoder type!", u"Error encoder type", wx.YES_NO | wx.ICON_QUESTION)
        		dlg.ShowModal()
			flag = 1
		
		crf = self.m_textCtrl6.GetValue()

		if flag == 0: 
			str = './ffmpeg -i ./y4m/source.y4m -c:v %s -crf %s -b:v 0 ./encoded_ui/encoded_%s_crf%s.mkv' %(lib, crf, encoder, crf)
			self.m_textCtrl4.SetValue(str)

	def encode_crf(self, event):
		self.m_button4.Enable(False)
		str = self.m_textCtrl4.GetValue()
		if os.system(str) == 0:
			dlg = wx.MessageDialog(None, u"Encode complete!", u"Encode complete", wx.YES_NO | wx.ICON_QUESTION)
			dlg.ShowModal()
		#else:
			#dlg = wx.MessageDialog(None, u"Wrong bitrate!", u"ncode Wrong bitrate", wx.YES_NO | wx.ICON_QUESTION)
		self.m_button4.Enable(True)

	def translate_decode(self, event):

		flag = 0
		encoder = self.m_textCtrl8.GetValue()
		if encoder == 'x264':
			lib = 'x264'
		elif encoder == 'x265':
			lib = 'x265'
		elif encoder == 'vp9':
			lib = 'vp9'
		else:
			dlg = wx.MessageDialog(None, u"Error encoder type!", u"Error encoder type", wx.YES_NO | wx.ICON_QUESTION)
        		dlg.ShowModal()
			flag = 1
		
		bitrate_crf = self.m_textCtrl9.GetValue()
		if 'K' not in bitrate_crf and 'M' not in bitrate_crf:
			bitrate_crf = 'crf' + bitrate_crf

		if flag == 0: 
			str = './ffmpeg -i ./encoded_ui/encoded_%s_%s.mkv ./decoded_ui/decoded_%s_%s.y4m' %(lib, bitrate_crf, lib, bitrate_crf)
			self.m_textCtrl7.SetValue(str)

	def decode(self, event):
	
		self.m_button6.Enable(False)
		str = self.m_textCtrl7.GetValue()
		
		df = pd.DataFrame(columns=['CODEC', 'PSNR', 'SSIM', 'VMAF'])
		
		print("decoding...")
		#decode
		os.system(str)
		
		encoder = self.m_textCtrl8.GetValue()
		if encoder == 'x264':
			lib = 'x264'
		elif encoder == 'x265':
			lib = 'x265'
		elif encoder == 'vp9':
			lib = 'vp9'
		
		bitrate_crf = self.m_textCtrl9.GetValue()
		if 'K' not in bitrate_crf and 'M' not in bitrate_crf:
			bitrate_crf = 'crf' + bitrate_crf
			
		label = encoder + '_' + bitrate_crf
		
		metrics = [label]
		
		print("\ncomputing PSNR...")
		#compute PSNR
		logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded_ui/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
		psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
		print psnr
		metrics.append(psnr)

		print("\ncomputing SSIM...")
		#compute SSIM
		logssim = commands.getstatusoutput("./ffmpeg -i ./decoded_ui/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
		ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
		print ssim
		metrics.append(ssim)

		print("\ncomputing VMAF...")
		#compute VMAF
		logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded_ui/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
		vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
		print vmaf
		metrics.append(vmaf)

		df.loc[0,:] = metrics

		os.system("rm -f ./decoded_ui/decoded_%s.y4m" %label)

		df.to_csv("metrics_ui.csv")
		
		dlg = wx.MessageDialog(None, u"Decode complete! Please check the 'metrics_ui.csv' file to observe PSNR, SSIM and VMAF in ffmpeg_static folder!", u"Encode complete", wx.YES_NO | wx.ICON_QUESTION)
		dlg.ShowModal()

		self.m_button6.Enable(True)
		
	
	def __del__( self ):
		pass


os.chdir("..")
os.chdir("./ffmpeg_static_with_VMAF/ffmpeg_static")
os.system("pwd")
app = wx.App()
win = MyFrame1(parent=None)
win.Show()
app.MainLoop()

