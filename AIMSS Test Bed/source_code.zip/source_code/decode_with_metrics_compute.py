import os
import re
import commands
import pandas as pd

#os.chdir("/home/augus/ffmpeg_static_with_VMAF/ffmpeg_static")
os.chdir("..")
os.chdir("./ffmpeg_static_with_VMAF/ffmpeg_static")
os.system("pwd")

#list0 = ["x264_32K"]
#bitrate x264+x265
list1 = ["x264_32K", "x264_64K", "x264_128K", "x264_256K", "x264_512K", "x264_768K", "x264_1M", "x264_1_25M", "x264_1_5M", "x264_1_75M", "x264_2M", "x264_3M", "x264_4M", "x264_5M", "x265_32K", "x265_64K", "x265_128K", "x265_256K", "x265_512K", "x265_768K", "x265_1M", "x265_1_25M", "x265_1_5M", "x265_1_75M", "x265_2M", "x265_3M", "x265_4M", "x265_5M"]
#bitrate vp9
list2 = ["vp9_32K", "vp9_64K", "vp9_128K", "vp9_256K", "vp9_512K", "vp9_768K", "vp9_1M", "vp9_1_25M", "vp9_1_5M", "vp9_1_75M", "vp9_2M", "vp9_3M", "vp9_4M", "vp9_5M"]
#bitrate av1
list3 = ["av1_32K", "av1_64K", "av1_128K", "av1_1M", "av1_2M"]
#crf 51-15 all
list4 = ["x264_crf51", "x265_crf51", "vp9_crf51", "av1_crf51", "x264_crf45", "x265_crf45", "vp9_crf45", "x264_crf39", "x265_crf39", "vp9_crf39", "x264_crf33", "x265_crf33", "vp9_crf33", "av1_crf33", "x264_crf27", "x265_crf27", "vp9_crf27", "x264_crf21", "x265_crf21", "vp9_crf21", "x264_crf15", "x265_crf15", "vp9_crf15", "av1_crf15"]

df = pd.DataFrame(columns=['CODEC', 'PSNR', 'SSIM', 'VMAF'])

for i in range(len(list1)):
	
	label = list1[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded/encoded_%s.mp4 ./decoded/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	#logvmaf = os.popen("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=352x288:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label).readlines()[2]
	#vmaf = re.findall(r"\d+\.?\d*",logvmaf)[0]
	#print vmaf
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i,:] = metrics

	os.system("rm -f ./decoded/decoded_%s.y4m" %label)

df.to_csv("metrics_part1.csv")

#df = pd.read_csv("metrics_part1.csv")
#df = df.iloc[:,1:5]

for i in range(len(list2)):
	
	label = list2[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded/encoded_%s.mkv ./decoded/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	#logvmaf = os.popen("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=352x288:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label).readlines()[2]
	#vmaf = re.findall(r"\d+\.?\d*",logvmaf)[0]
	#print vmaf
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i+len(list1),:] = metrics

	os.system("rm -f ./decoded/decoded_%s.y4m" %label)

df.to_csv("metrics_part2.csv")

#df = pd.read_csv("metrics_part2.csv")
#df = df.iloc[:,1:5]

for i in range(len(list3)):
	
	label = list3[i]
	metrics = [label]

	print("decoding...")
	#decode
	os.system("./ffmpeg -i ./encoded/encoded_%s.mkv ./decoded/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	#logvmaf = os.popen("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=352x288:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label).readlines()[2]
	#vmaf = re.findall(r"\d+\.?\d*",logvmaf)[0]
	#print vmaf
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i+len(list1)+len(list2),:] = metrics

	os.system("rm -f ./decoded/decoded_%s.y4m" %label)

df.to_csv("metrics_part3.csv") 

#df = pd.read_csv("metrics_part3.csv")
#df = df.iloc[:,1:5]

for i in range(len(list4)):
	
	label = list4[i]
	metrics = [label]

	print("decoding...")
	#decode
	if "x" in label:
		os.system("./ffmpeg -i ./encoded_crf/encoded_%s.mp4 ./decoded_crf/decoded_%s.y4m" %(label, label))
	elif "vp" in label or "av" in label:
		os.system("./ffmpeg -i ./encoded_crf/encoded_%s.mkv ./decoded_crf/decoded_%s.y4m" %(label, label))
	
	print("\ncomputing PSNR...")
	#compute PSNR
	logpsnr = commands.getstatusoutput("./ffmpeg -i ./decoded_crf/decoded_%s.y4m -i ./y4m/source.y4m -lavfi psnr -f null -" %label) [1]
	psnr = re.findall("\d+\.?\d*",re.findall("average:\d+\.?\d*",logpsnr)[0])[0]
	print psnr
	metrics.append(psnr)

	print("\ncomputing SSIM...")
	#compute SSIM
	logssim = commands.getstatusoutput("./ffmpeg -i ./decoded_crf/decoded_%s.y4m -i ./y4m/source.y4m -lavfi ssim -f null -" %label) [1]
	ssim = re.findall("\d+\.?\d*",re.findall("All:\d+\.?\d*",logssim)[0])[0]
	print ssim
	metrics.append(ssim)

	print("\ncomputing VMAF...")
	#compute VMAF
	#logvmaf = os.popen("./ffmpeg -i ./decoded/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=352x288:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label).readlines()[2]
	#vmaf = re.findall(r"\d+\.?\d*",logvmaf)[0]
	#print vmaf
	logvmaf = commands.getstatusoutput("./ffmpeg -i ./decoded_crf/decoded_%s.y4m -i ./y4m/source.y4m -filter_complex \"[0:v]scale=1920x1080:flags=bicubic[main];[main][1:v]libvmaf\" -f null -" %label) [1]
	vmaf = re.findall("\d+\.?\d*",re.findall("VMAF score = \d+\.?\d*",logvmaf)[0])[0]
	print vmaf
	metrics.append(vmaf)

	df.loc[i+len(list1)+len(list2)+len(list3),:] = metrics

	os.system("rm -f ./decoded_crf/decoded_%s.y4m" %label)

df.to_csv("metrics_final.csv") 
