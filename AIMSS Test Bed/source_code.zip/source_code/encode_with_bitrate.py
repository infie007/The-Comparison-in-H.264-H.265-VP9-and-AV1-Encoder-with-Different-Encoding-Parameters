import os
import time

os.chdir("..")
os.chdir("./ffmpeg_static_with_VMAF/ffmpeg_static")
os.system("pwd")

print("encode the source file with the x264 encoder...")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 32K ./encoded/encoded_x264_32K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 64K ./encoded/encoded_x264_64K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 128K ./encoded/encoded_x264_128K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 256K ./encoded/encoded_x264_256K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 512K ./encoded/encoded_x264_512K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 768K ./encoded/encoded_x264_768K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1M ./encoded/encoded_x264_1M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1.25M ./encoded/encoded_x264_1_25M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1.5M ./encoded/encoded_x264_1_5M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 1.75M ./encoded/encoded_x264_1_75M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 2M ./encoded/encoded_x264_2M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 3M ./encoded/encoded_x264_3M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 4M ./encoded/encoded_x264_4M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx264 -b:v 5M ./encoded/encoded_x264_5M.mp4")


print("\nencode the source file with the x265/hevc encoder...")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 32K ./encoded/encoded_x265_32K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 64K ./encoded/encoded_x265_64K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 128K ./encoded/encoded_x265_128K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 256K ./encoded/encoded_x265_256K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 512K ./encoded/encoded_x265_512K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 768K ./encoded/encoded_x265_768K.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 1M ./encoded/encoded_x265_1M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 1.25M ./encoded/encoded_x265_1_25M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 1.5M ./encoded/encoded_x265_1_5M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 1.75M ./encoded/encoded_x265_1_75M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 2M ./encoded/encoded_x265_2M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 3M ./encoded/encoded_x265_3M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 4M ./encoded/encoded_x265_4M.mp4")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libx265 -b:v 5M ./encoded/encoded_x265_5M.mp4")


print("\nencode the source file with the vp9 encoder...")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 32K ./encoded/encoded_vp9_32K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 64K ./encoded/encoded_vp9_64K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 128K ./encoded/encoded_vp9_128K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 256K ./encoded/encoded_vp9_256K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 512K ./encoded/encoded_vp9_512K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 768K ./encoded/encoded_vp9_768K.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 1M ./encoded/encoded_vp9_1M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 1.25M ./encoded/encoded_vp9_1_25M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 1.5M ./encoded/encoded_vp9_1_5M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 1.75M ./encoded/encoded_vp9_1_75M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 2M ./encoded/encoded_vp9_2M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 3M ./encoded/encoded_vp9_3M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 4M ./encoded/encoded_vp9_4M.mkv")
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libvpx-vp9 -b:v 5M ./encoded/encoded_vp9_5M.mkv")

print("encode the source file with the av1 encoder...")
time32 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 32K -strict experimental ./encoded/encoded_av1_32K.mkv")
time64 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 64K -strict experimental ./encoded/encoded_av1_64K.mkv")
time128 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 128K -strict experimental ./encoded/encoded_av1_128K.mkv")
time256 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 256K -strict experimental ./encoded/encoded_av1_256K.mkv")
time512 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 512K -strict experimental ./encoded/encoded_av1_512K.mkv")
time768 = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 768K -strict experimental ./encoded/encoded_av1_768K.mkv")
time1K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 1M -strict experimental ./encoded/encoded_av1_1M.mkv")
time1_25K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 1.25M -strict experimental ./encoded/encoded_av1_1_25M.mkv")
time1_5K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 1.5M -strict experimental ./encoded/encoded_av1_1_5M.mkv")
time1_75K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 1.75M -strict experimental ./encoded/encoded_av1_1_75M.mkv")
time2K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 2M -strict experimental ./encoded/encoded_av1_2M.mkv")
time3K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 3M -strict experimental ./encoded/encoded_av1_3M.mkv")
time4K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 4M -strict experimental ./encoded/encoded_av1_4M.mkv")
time5K = time.time()
os.system("./ffmpeg -i ./y4m/source.y4m -c:v libaom-av1 -b:v 5M -strict experimental ./encoded/encoded_av1_5M.mkv")
timeend = time.time()

time_record = [time32,time64,time128,time256,time512,time768,time1K,time1_25K,time1_5K,time1_75K,time2K,time3K,time4K,time5K,timeend]
print time_record

file = open('time_record_av1.txt','w') 
file.write(str(time_record)); 
file.close() 





